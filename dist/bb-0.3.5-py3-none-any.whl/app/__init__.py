#-*- coding: utf-8 -*-
"""
    BBCLI: A CLI utility that can help you create pull requests
"""
__version__ = '0.3.5'
