# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['app', 'app.scripts', 'app.utils']

package_data = \
{'': ['*']}

install_requires = \
['pyperclip>=1.8.2,<2.0.0',
 'requests>=2.27.1,<3.0.0',
 'rich>=11.1.0,<12.0.0',
 'typer[all]>=0.4.0,<0.5.0']

entry_points = \
{'console_scripts': ['bb = app.main:app']}

setup_kwargs = {
    'name': 'bb',
    'version': '0.3.5',
    'description': 'CLI Utility that can manage bitbucket pull requests',
    'long_description': "# BBCLI\n\nBitbucket CLI (bbcli): A command line utility that will help you manage pull requests from your terminal.\n\n---\n\n## REQUIREMENTS\n\n* Python3 (3.6.2 or Higher) & Pip3 (latest recommended)\n* Write access token from bitbucket\n\n---\n\n### INSTALL\n\na. Place the .alt file in your home directory\n\n```text\n[default]\nbitbucket_host=https://bitbucket.mycompany.com\nusername=myusername\ntoken=thisisarandomwriteaccesstokengeneratedbybitbucket\n```\n\nb. clone the git repository\n\nManual\n\n```text\ngit clone https://github.com/psadi/bbcli.git\ncd bb\npip3 install --user -r requirements.txt\npoetry build\npip3 install --user dist/bb-<version>.tar.gz\n```\n\nFrom Releases\n\n* Download the latest build from releases page\n\n```text\npip3 install --user bb-<version>.tar.gz\n```\n\nc. Validate\n\n* If the .alt file is placed in you home directory and setup didnt throw any error, then\n\n```text\nbb test\n```\n\n* if all went well, you should get a response like this\n\n```text\n➜ bb test\nᐅ Validating connection with 'https://bitbucket.<company>.com'...\n✅ OK\n```\n\n### WHAT CAN IT DO?\n\n* Create pull requests\n\n```text\nbb create --target master           --> creates pull request and asks for confirmation\nbb create --target master --yes    --> creates pull request without prompt\n```\n\n* Show diff of files (ADD/DELETE/MODIFY & RENAME) as an overview\n\n```text\nbb create --target master --yes --diff     --> creates pull request without prompt and shows diff from the PR raised\nbb delete --target 1 --yes --diff          --> deletes pull request without prompt and shows diff befoew PR is deleted\n```\n\n* Delete pull requests\n\n```text\nbb delete --target 1                        --> deletes the given  pull request number with confirmation prompt\nbb delete --target 1 --yes                 --> deletes the given  pull request number without prompt\n```\n\n* View pull requests authored/reviewer for the current repository\n\n```text\nbb view             --> show pull requests authored[Default]\nbb view --author    --> show pull requests authored\nbb view --reviewer  --> show pull requests that you are a reviewer\n```\n\n### Enable shell autocompletions\n\n* BB is equipped with shell auto completions, To enable it,\n\n```text\nbb --install-completion     Install completion for the current shell (One time setup)\nbb  --show-completion       Show completion for the current shell, to copy it or customize the installation.\n```\n\n---\n\n### Points to Ponder\n\n* This utility is tested with bitbucket enterprise version 6.10.10\n* I have personally tested it in Linux, Windows(Powershell and Command Prompt), MacOS and GIT Bash and it works flawlessly\n* In case if your ID gets locked the token wont work, you may need to reset your ID (Token can remain the same)\n* At times if there are frequent account lockouts, Bitbucket will prompt you to enter CAPTCHA, you may need to relogin with CAPTCHA validation in your broswer once else connection will fail\n\n---\n\n### 💡 PRO TIP 💡\n\n* Use [Windows Terminal](https://github.com/microsoft/terminal) for better visual rendering\n* Use Nerd font for better font/icon support, I personally use [DroidSansMono Nerd Font](https://github.com/ryanoasis/nerd-fonts/releases/download/v2.1.0/DroidSansMono.zip)\n  * [Preview Font](https://www.programmingfonts.org/#droid-sans)\n\n---\n\n🕺🕺 That's all folks !!\n\n🕺🕺 Enjoy being more efficient 😊\n\n",
    'author': 'P S, Adithya',
    'author_email': 'adithya3494@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6.2,<4.0.0',
}


setup(**setup_kwargs)
